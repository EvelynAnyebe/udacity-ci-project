## Project screen shots

In this project, an auto deployment pipeline for CI-CD for an example application as part of the Udacity cloud DevOps program is carried out. This project uses the started code from Udacity.

The following screenshots are provided for every stage of the project.

- SCREENSHOT01

For build jobs that failed because of compile errors.

- SCREESHOT02

For intentional failing tests. There are two of these screenshots. `SCREENSHOT02-FRONTEND` AND `SCREENSHOT02-BACKEND`

- SCREENSHOT03

For critical vulnerabilities There are two of these screenshots. `SCREENSHOT03-FRONTEND` AND `SCREENSHOT03-BACKEND`

- SCREENSHOTS04
  For slack alerts

- SCREENSHOT05
  For deploy infrastructure

- SREENSHOT06
